package com.example.app02;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void sortear(View view){
        long[] numero = new long[6];
        TextView txtNum1 = findViewById(R.id.txtN1);
        TextView txtNum2 = findViewById(R.id.txtN2);
        TextView txtNum3 = findViewById(R.id.txtN3);
        TextView txtNum4 = findViewById(R.id.txtN4);
        TextView txtNum5 = findViewById(R.id.txtN5);
        TextView txtNum6 = findViewById(R.id.txtN6);
        for (int i=0; i<6; i++)
            numero[i] = Math.round(Math.random()*60);
        txtNum1.setText(String.valueOf(numero[0]));
        txtNum2.setText(String.valueOf(numero[1]));
        txtNum3.setText(String.valueOf(numero[2]));
        txtNum4.setText(String.valueOf(numero[3]));
        txtNum5.setText(String.valueOf(numero[4]));
        txtNum6.setText(String.valueOf(numero[5]));
    }
}